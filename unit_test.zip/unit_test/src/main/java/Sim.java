package src.main.java;

public class Sim {
    public int add (int numberA, int numberB){
        return numberA * numberB;
    }
}