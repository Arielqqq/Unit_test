package src.main.test.java;

import static org.junit.jupiter.api.Assertions.*;

class SimTest {
    void twoPlusTwoShouldEqualFour() {
        var calculator = new SimpleCalculator();
        assertEquals(4,calculator.add(2,2));
    }
}